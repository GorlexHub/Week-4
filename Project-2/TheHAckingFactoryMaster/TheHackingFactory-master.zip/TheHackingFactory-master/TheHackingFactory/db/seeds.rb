require 'faker'

10.times do
  Assembly.create!(name: Faker::RickAndMorty.location)
end

10.times do
  Part.create!(part_number: Faker::RickAndMorty.character)
end

Assembly.all.each do |ass|
  rand(10).times do
    ass.parts << Part.find(rand(Part.first.id..Part.last.id))
  end
end
