require 'test_helper'

class StrollTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
