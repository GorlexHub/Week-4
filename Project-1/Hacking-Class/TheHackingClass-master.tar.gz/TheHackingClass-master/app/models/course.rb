class Course < ApplicationRecord
    has_many :students
end
