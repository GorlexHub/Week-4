class Student < ApplicationRecord
    has_one :course
end
