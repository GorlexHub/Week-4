# This file should contain all the record creation needed to seed the database with its default values.
# The data can then be loaded with the rails db:seed command (or created alongside the database with db:setup).
#
# Examples:
#
#   movies = Movie.create([{ name: 'Star Wars' }, { name: 'Lord of the Rings' }])
#   Character.create(name: 'Luke', movie: movies.first)

require 'faker'

50.times do     
    User.create!(last_name: Faker::Name.last_name, first_name: Faker::Name.first_name, email: Faker::Internet.email, age: Faker::Number.between(18, 77))
end

50.times do     
    Post.create!(user_id: Faker::Number.between(User.first.id, User.last.id), title: Faker::Vehicle.manufacture, url: Faker::Internet.url)
end

20.times do
    Comment.create!(user_id: Faker::Number.between(User.first.id, User.last.id), post_id: Faker::Number.between(Post.first.id, Post.last.id), content: Faker::NewGirl.quote)
end

10.times do
    Comment.create!(user_id: Faker::Number.between(User.first.id, User.last.id), post_id: Faker::Number.between(Post.first.id, Post.last.id), comment_id: Faker::Number.between(Comment.first.id, Comment.last.id), content: Faker::NewGirl.quote)
end
