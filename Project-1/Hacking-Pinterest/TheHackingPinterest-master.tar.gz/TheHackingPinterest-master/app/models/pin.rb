class Pin < ApplicationRecord
    has_many :comments
end
