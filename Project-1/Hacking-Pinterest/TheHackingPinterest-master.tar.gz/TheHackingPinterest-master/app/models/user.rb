class User < ApplicationRecord
    has_many :pins
end
