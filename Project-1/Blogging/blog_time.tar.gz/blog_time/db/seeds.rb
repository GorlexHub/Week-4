require 'faker'

10.times do
  User.create!(first_name: Faker::Name.first_name, last_name: Faker::Name.last_name, email: Faker::Internet.email)
end

10.times do
  Category.create!(name: Faker::RickAndMorty.location)
end

10.times do
  Article.create!(user_id: Faker::Number.between(User.first.id, User.last.id), category_id: Faker::Number.between(Category.first.id, Category.last.id), title: Faker::RickAndMorty.character, content: Faker::RickAndMorty.quote)
end

10.times do
  Comment.create!(user_id: Faker::Number.between(User.first.id, User.last.id), article_id: Faker::Number.between(Article.first.id, Article.last.id), content: Faker::RickAndMorty.quote)
end

15.times do
  Like.create!(user_id: Faker::Number.between(User.first.id, User.last.id), article_id: Faker::Number.between(Article.first.id, Article.last.id))
end
