class Lesson < ApplicationRecord
  belongs_to :course
end
