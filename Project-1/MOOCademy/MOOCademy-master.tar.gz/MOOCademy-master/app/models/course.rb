class Course < ApplicationRecord
  has_many :lessons
end
